//
//  SMFApplication.h
//  Smartface
//
//  Created by Tolga Haliloğlu on 02/03/2017.
//
//

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SMFApplicationExport <NSObject, JSExport>

+(NSDictionary *)dataCounters;

+(BOOL)canOpenUrl:(NSString *)urlString;
JSExportAs(call, +(void)call:(NSString *)uri
                    withData:(NSDictionary *)data
         withSuccessCallback:(JSValue *)onSuccess
         withFailureCallback:(JSValue *)onFailure);

+(void)exit;
+(void)restart;
-(BOOL)performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem;
+ (instancetype)sharedInstance;
@property (strong) JSValue *performActionForShortcutItemShortcutItem;

+(BOOL)isEmulator;

@end

@interface SMFApplication : NSObject <SMFApplicationExport>

+(NSDictionary *)dataCounters;

+(BOOL)canOpenUrl:(NSString *)urlString;
+(void)call:(NSString *)uri
   withData:(NSDictionary *)data
withSuccessCallback:(JSValue *)onSuccess
withFailureCallback:(JSValue *)onFailure;

+(void)exit;
+(void)restart;
+ (instancetype)sharedInstance;
-(BOOL)performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem;
@property (strong) JSValue *performActionForShortcutItemShortcutItem;

+(BOOL)isEmulator;

@end

NS_ASSUME_NONNULL_END
